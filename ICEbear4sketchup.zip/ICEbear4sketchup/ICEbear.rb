require 'win32ole'
require 'rexml/document'
include REXML

#Create toolbar - name
toolbar = UI::Toolbar.new "ICEbear"

# This toolbar executes Sketchup geometry to xml-file - and opens the ICEbear program
cmd = UI::Command.new("ICEbear") {
  
mod = Sketchup.active_model 		# Open model
ent = mod.entities 					# All entities in model

# Create array of faces
numFaces = 0	# Face counter	
i = 0			# Variable to enter the right position of the array
faces = Array.new	# Define the face array

ent.each do |enti|	# Loop through all entities in model
  if enti.is_a?(Sketchup::Face)		#If current entity is a Face
    numFaces += 1	# Add 1 to the face counter
    faces[i] = enti	# Set the face into the faces-array
    i += 1 			# Add 1 to the position variable
  end				# End if-loop
end					# End For-each loop


# Get values from the faces based on the material
roofArea = 0
wallArea = 0
groundArea = 0
floorArea = 0
inletArea = 0
outletArea = 0

faces.each do |fac|		# Loop through each face in the faces-array
  faceMaterial = 0
  
  if fac.material != nil		# Does face have material?	
    faceMaterial = fac.material.name   	# Get face material name
  end
  if fac.back_material != nil  
     faceBackMaterial = fac.back_material.name
  end
  
  if faceMaterial == "Roof" || faceBackMaterial == "Roof"      					# If face material is roof
        roofArea = roofArea + (fac.area * 0.00064516) 		# Determine roofArea       
  end													# End if-loop
      
   if faceMaterial == "ExternalWall" || faceBackMaterial == "ExternalWall" || faceMaterial == "ExternalWallInlet" || faceBackMaterial == "ExternalWallInlet" || faceMaterial == "ExternalWallOutlet" || faceBackMaterial == "ExternalWallOutlet"
        wallArea = wallArea + (fac.area * 0.00064516)
  end
      
  if faceMaterial == "FloorFacingGround" || faceBackMaterial == "FloorFacingGround"
        groundArea = groundArea + (fac.area * 0.00064516)
  end
      
  if faceMaterial == "Floor" || faceBackMaterial == "Floor"
        floorArea = floorArea + (fac.area * 0.00064516)
  end			
end						# End for-each loop

# Create CSV-file
csvfile = "C:/ICEbear/Grasshopper/GH_14/Roaming/DaylightLuxLevel.csv"		#File path to csv-file for daylight
csvdoc = Document.new				#Create new document to overwrite any earlier daylight calculation


# Create XML-file
xmlfile = "C:/ICEbear/BuildingGeometry.xml"		#File path to xml-file
xmldoc = Document.new				#Create new document


Room = xmldoc.add_element 'Room'	# Outer Element
room = Room.add_element 'room'		# Element room in Room
name = room.add_element 'name'		# Element name in room
name.add_text 'buildingGeometry'	# value of name

roof = Room.add_element 'roof'		# Element roof in Room
area_roof = roof.add_element 'area' # Element area in roof
area_roof.add_text roofArea.to_s	# value of area - OBS "to.s" is to string for the xml to work

wall = Room.add_element 'wall'		# Element wall in Room
area_wall = wall.add_element 'area'	# Element area in wall
area_wall.add_text wallArea.to_s	# value of area

curtainWalls = Room.add_element 'curtainWalls' 	# Element curtainWalls in Room

floor = Room.add_element 'floor'	# Element floor in Room
area_floor = floor.add_element 'area' #Element area in floor
area_floor.add_text floorArea.to_s	# value of area

ground = Room.add_element 'ground'	# Element ground in Room
area_ground = ground.add_element 'area' # Element area in ground
area_ground.add_text groundArea.to_s # value of area
 
windows = Room.add_element 'windows'			# Element windows in Room
shadingSurfaces = Room.add_element 'shadingSurfaces'	# Element shadingSurfaces in Room
internalWalls = Room.add_element 'internalWalls'	# Element internalWalls in
internalCeilings = Room.add_element 'internalCeilings' 	#Element internalCeilings in Room
internalFloors = Room.add_element 'internalFloors' 		#Element internalFloors in Room
internalGrids = Room.add_element 'internalGrids' 		#Element internalGrids in Room
inlets= Room.add_element 'inlets'			# Element inlets in Room
outlets= Room.add_element 'outlets'			# Element outlets in Room

 faces.each do |fac|		# Loop through each face in the faces-array
    
  faceMaterial = 0
 
  if fac.material != nil				# Does face have material?	
    faceMaterial = fac.material.name   	# Get face material name
  end
  if fac.back_material != nil
    faceBackMaterial = fac.back_material.name
  end

  #-----Windows-----
      if faceMaterial == "Window" || faceMaterial == "WindowInlet" || faceMaterial == "WindowOutlet"    	# If face material is windows
        windowArea = fac.area * 0.00064516 		# Determine windowArea  
		
        window = windows.add_element 'window'		# Element window in windows
        area_window = window.add_element 'area'		# Element area in window
        area_window.add_text windowArea.to_s		# Value of area (in xml)
        
		
		windowEdges = fac.edges				# Get edges from face (window)
        windowPerimeter = 0		# Define window perimeter
        
        windowEdges.each do |edge|		# Loop through all edges in current window
			windowPerimeter = windowPerimeter + edge.length *  0.0254		# For each edge, get length and add to window perimeter
        end     # End for-each edge-loop
        
        perimeter_window = window.add_element 'perimeter'	# Element perimeter in window
        perimeter_window.add_text windowPerimeter.to_s		# Value of perimenter (in xml)
        
		
        cornerCoordinates = window.add_element 'cornerCoordinates'	# Element coornerCoordinates in window
        
        windowVertices = fac.vertices		# Get window corners from face
        
		windowVertices.each do |vert|	# Loop through all vertices (corners) in current window
        
          windowVertex = vert.position	# For each corner get point3D coordinates (x,y,z)
        
          corners = cornerCoordinates.add_element 'corners'	# Element corners in cornerCoordinates
          x_corner = corners.add_element 'x'			# Element x in corners
          x_corner.add_text (windowVertex.x * 0.0254).to_s	# Value of x (in xml)
          
          y_corner = corners.add_element 'y'			# Element y in corners
          y_corner.add_text (windowVertex.y * 0.0254).to_s	# Value of y (in xml)
          
          z_corner = corners.add_element 'z'			# Element z in corners
          z_corner.add_text (windowVertex.z * 0.0254).to_s	# Value of z (in xml)
        end		# End for-each vertices-loop
        
        windowNormal = fac.normal		# Get normal of window-face
        
        if fac.material == nil
         windowNormal = Geom::Vector3d.new(-1 * windowNormal.x, -1 * windowNormal.y, -1 * windowNormal.z)		# Get normal of window-face
        end
		
        yAxis = Geom::Vector3d.new(0,1,0)	# Create vector of y-axis
        windowNormalXY = Geom::Vector3d.new(windowNormal.x, windowNormal.y,0)
        windowOrientation = 0	# Define windowOrientation
	
	if windowNormalXY.x == 0 and  windowNormalXY.y == 0	# Start if argument
                    windowOrientation = 0	# Determine angle in degrees (orientation is negative in east direction)
       	else
	if windowNormalXY.x == 0	# Start if argument
          angleRad = yAxis.angle_between windowNormalXY	# Determine angle between yaxis and windowNormal (rad)
          windowOrientation = (angleRad * 180 / Math::PI).abs 	# Determine angle in degrees (orientation is negative in east direction)
        end		# End if argument
	if windowNormalXY.x < 0	# Start if argument (west)
          angleRad = yAxis.angle_between windowNormalXY	# Determine angle between yaxis and windowNormal (rad)
          windowOrientation = -angleRad * 180 / Math::PI	# Determine angle in degrees (orientation is positive in west direction)
        end		# End if argument
        if windowNormalXY.x > 0	# Start if argument (east)
          angleRad = yAxis.angle_between windowNormalXY	# Determine angle between yaxis and windowNormal (rad)
          windowOrientation = 1 * angleRad * 180 / Math::PI		# Determine angle in degrees (orientation is negative in east direction)
        end
	end

        orientation_window = window.add_element 'orientation'	# Element orientation in window
        orientation_window.add_text windowOrientation.to_s		# Value of orientation (in xml)
        
	windowTilt = 0	# Define windowTilt

	if windowNormalXY.x == 0 and  windowNormalXY.y == 0	# Start if argument
            windowTilt= 0	# Determine angle in degrees (orientation is negative in east direction)
	else
            zAxis = Geom::Vector3d.new(0,0,1)			# Create vector of z-axis
            windowTilt = (zAxis.angle_between windowNormal) * 180 / Math::PI	#Determine window tilt, as angle between z-axis and windowNormal
        end

        tilt_window = window.add_element 'tilt'		# Element tilt in window
        tilt_window.add_text windowTilt.to_s		# Value of tilt (in xml)

	#Window edges:
			
		surfaceEdges = window.add_element 'surfaceEdges'		# Element surfaceEdges in window
		
		windowEdges = fac.outer_loop.edges			# Get edges of face of window
		
		windowEdges.each do |edge|		# Loop through all edges in window face
			
			windowEdgeStart = edge.start.position 		# For each corner get Point3D start coordinte (x, y, z)
			windowEdgeEnd = edge.end.position				# For each corner get Point3D end coordinte (x, y, z)
			
			edge = surfaceEdges.add_element 'edge'		# Element edge in surfaceEdges
			start_vertex = edge.add_element 'start'		# Element start in edge
			
			x_coor = start_vertex.add_element 'x'				# Element x in start
			x_coor.add_text (windowEdgeStart.x * 0.0254).to_s		# Value of start vertex x (in xml)
			
			y_coor = start_vertex.add_element 'y'		# Element x in start
			y_coor.add_text (windowEdgeStart.y * 0.0254).to_s	# Value of start vertex y (in xml)
			
			z_coor = start_vertex.add_element 'z'		# Element x in start
			z_coor.add_text (windowEdgeStart.z * 0.0254).to_s	# Value of start vertex z (in xml)
			
			
			end_vertex = edge.add_element 'end'		# Element start in edge
			
			x_coor = end_vertex.add_element 'x'		# Element x in end
			x_coor.add_text (windowEdgeEnd.x * 0.0254).to_s	# Value of end vertex x (in xml)
			
			y_coor = end_vertex.add_element 'y'		# Element x in end
			y_coor.add_text (windowEdgeEnd.y * 0.0254).to_s	# Value of end vertex y (in xml)
			
			z_coor = end_vertex.add_element 'z'		# Element x in end
			z_coor.add_text (windowEdgeEnd.z * 0.0254).to_s	# Value of end vertex z (in xml)

		end   # End for each edge-loop

        
      end				# End if-loop (material is windows)



#-----Inlets----
if faceMaterial == "ExternalWallInlet" || faceMaterial == "WindowInlet"        	# If face material is inlet and window
        inletArea = fac.area * 0.00064516 		# Determine inletArea  
	        
	# add element to inlet:
	inlet = inlets.add_element 'inlet'		# Element window in windows
        area_inlet = inlet.add_element 'area'		# Element area in window
        area_inlet.add_text inletArea.to_s		# Value of area (in xml)
		    
	windowEdges = fac.edges				# Get edges from face (window)
        windowPerimeter = 0		# Define window perimeter
        
        windowEdges.each do |edge|		# Loop through all edges in current window
		windowPerimeter = windowPerimeter + edge.length *  0.0254		# For each edge, get length and add to window perimeter
        end     # End for-each edge-loop
                       
	perimeter_inlet = inlet.add_element 'perimeter'	# Element perimeter in inlet
        perimeter_inlet.add_text windowPerimeter.to_s		# Value of perimenter (in xml)
        
	#____Inlet coordinates:
	cornerCoordinates = inlet.add_element 'cornerCoordinates'	# Element coornerCoordinates in window
       
        windowVertices = fac.vertices		# Get window corners from face
        
		windowVertices.each do |vert|	# Loop through all vertices (corners) in current window
        
          windowVertex = vert.position	# For each corner get point3D coordinates (x,y,z)
        
          corners = cornerCoordinates.add_element 'corners'	# Element corners in cornerCoordinates
          x_corner = corners.add_element 'x'			# Element x in corners
          x_corner.add_text (windowVertex.x * 0.0254).to_s	# Value of x (in xml)
          
          y_corner = corners.add_element 'y'			# Element y in corners
          y_corner.add_text (windowVertex.y * 0.0254).to_s	# Value of y (in xml)
          
          z_corner = corners.add_element 'z'			# Element z in corners
          z_corner.add_text (windowVertex.z * 0.0254).to_s	# Value of z (in xml)
        end		# End for-each vertices-loop
        
        windowNormal = fac.normal		# Get normal of window-face
        
        if fac.material == nil
         windowNormal = Geom::Vector3d.new(-1 * windowNormal.x, -1 * windowNormal.y, -1 * windowNormal.z)		# Get normal of window-face
        end
		
        yAxis = Geom::Vector3d.new(0,1,0)	# Create vector of y-axis
        windowNormalXY = Geom::Vector3d.new(windowNormal.x, windowNormal.y,0)
        windowOrientation = 0	# Define windowOrientation
		
        if windowNormalXY.x == 0	# Start if argument
          angleRad = yAxis.angle_between windowNormalXY	# Determine angle between yaxis and windowNormal (rad)
          windowOrientation = (angleRad * 180 / Math::PI).abs	# Determine angle in degrees (orientation is negative in east direction)
        end		# End if argument
	if windowNormalXY.x < 0	# Start if argument (west)
          angleRad = yAxis.angle_between windowNormalXY	# Determine angle between yaxis and windowNormal (rad)
          windowOrientation = -angleRad * 180 / Math::PI	# Determine angle in degrees (orientation is positive in west direction)
        end		# End if argument
        if windowNormalXY.x > 0	# Start if argument (east)
          angleRad = yAxis.angle_between windowNormalXY	# Determine angle between yaxis and windowNormal (rad)
          windowOrientation = 1 * angleRad * 180 / Math::PI		# Determine angle in degrees (orientation is negative in east direction)
        end	
       
	orientation_inlet = inlet.add_element 'orientation'	# Element orientation in Inlet
        orientation_inlet.add_text windowOrientation.to_s		# Value of orientation (in xml)
                

        zAxis = Geom::Vector3d.new(0,0,1)			# Create vector of z-axis
        windowTilt = (zAxis.angle_between windowNormal) * 180 / Math::PI	#Determine window tilt, as angle between z-axis and windowNormal
        
       
        tilt_inlet = inlet.add_element 'tilt'		# Element tilt in inlet
        tilt_inlet.add_text windowTilt.to_s		# Value of tilt (in xml)
        
      end				# End if-loop (material is Inlets)

#-----OUTLETS-------
if faceMaterial == "ExternalWallOutlet" || faceMaterial == "WindowOutlet"   	# If face material is outlet 
        outletArea = fac.area * 0.00064516 		# Determine outletArea  	
        
	# add element to outlet:
	outlet = outlets.add_element 'outlet'		# Element outlet in outlets
        area_outlet = outlet.add_element 'area'		# Element area in outlet
        area_outlet.add_text outletArea.to_s		# Value of area (in xml)
	
	        
	windowEdges = fac.edges				# Get edges from face (window)
        windowPerimeter = 0		# Define window perimeter
        
        windowEdges.each do |edge|		# Loop through all edges in current window
		windowPerimeter = windowPerimeter + edge.length *  0.0254		# For each edge, get length and add to window perimeter
        end     # End for-each edge-loop
                       
	perimeter_outlet = outlet.add_element 'perimeter'	# Element perimeter in outlet
        perimeter_outlet.add_text windowPerimeter.to_s		# Value of perimenter (in xml)
        	
	#____Outlet coordinates:
	cornerCoordinates = outlet.add_element 'cornerCoordinates'	# Element coornerCoordinates in window
       
        windowVertices = fac.vertices		# Get window corners from face
        
		windowVertices.each do |vert|	# Loop through all vertices (corners) in current window
        
          windowVertex = vert.position	# For each corner get point3D coordinates (x,y,z)
        
          corners = cornerCoordinates.add_element 'corners'	# Element corners in cornerCoordinates
          x_corner = corners.add_element 'x'			# Element x in corners
          x_corner.add_text (windowVertex.x * 0.0254).to_s	# Value of x (in xml)
          
          y_corner = corners.add_element 'y'			# Element y in corners
          y_corner.add_text (windowVertex.y * 0.0254).to_s	# Value of y (in xml)
          
          z_corner = corners.add_element 'z'			# Element z in corners
          z_corner.add_text (windowVertex.z * 0.0254).to_s	# Value of z (in xml)
        end		# End for-each vertices-loop
        
        windowNormal = fac.normal		# Get normal of window-face
        
        if fac.material == nil
         windowNormal = Geom::Vector3d.new(-1 * windowNormal.x, -1 * windowNormal.y, -1 * windowNormal.z)		# Get normal of window-face
        end
		
        yAxis = Geom::Vector3d.new(0,1,0)	# Create vector of y-axis
        windowNormalXY = Geom::Vector3d.new(windowNormal.x, windowNormal.y,0)
        windowOrientation = 0	# Define windowOrientation
		
        if windowNormalXY.x == 0	# Start if argument
          angleRad = yAxis.angle_between windowNormalXY	# Determine angle between yaxis and windowNormal (rad)
          windowOrientation = (angleRad * 180 / Math::PI).abs	# Determine angle in degrees (orientation is negative in east direction)
        end		# End if argument
	if windowNormalXY.x < 0	# Start if argument (west)
          angleRad = yAxis.angle_between windowNormalXY	# Determine angle between yaxis and windowNormal (rad)
          windowOrientation = -angleRad * 180 / Math::PI	# Determine angle in degrees (orientation is positive in west direction)
        end		# End if argument
        if windowNormalXY.x > 0	# Start if argument (east)
          angleRad = yAxis.angle_between windowNormalXY	# Determine angle between yaxis and windowNormal (rad)
          windowOrientation = 1 * angleRad * 180 / Math::PI		# Determine angle in degrees (orientation is negative in east direction)
        end	
	        
	orientation_outlet = outlet.add_element 'orientation'	# Element orientation in window
        orientation_outlet.add_text windowOrientation.to_s		# Value of orientation (in xml)
                

        zAxis = Geom::Vector3d.new(0,0,1)			# Create vector of z-axis
        windowTilt = (zAxis.angle_between windowNormal) * 180 / Math::PI	#Determine window tilt, as angle between z-axis and windowNormal
        
       
        tilt_outlet = outlet.add_element 'tilt'		# Element tilt in window
        tilt_outlet.add_text windowTilt.to_s		# Value of tilt (in xml)
        
      end				# End if-loop (material is Outlets)

#---EXTERNAL SHADINGS----

      if faceMaterial == "ExternalGeometry" || faceBackMaterial == "ExternalGeometry"      					# If face material is ExternalGeometry
        shading = shadingSurfaces.add_element 'shading'		# Element shading in shadingSurfaces
        
        cornerCoordinates = shading.add_element 'cornerCoordinates'	# Element coornerCoordinates in shading
        
        shadingVertices = fac.vertices		# Get vertices of face of external shading system
		
        shadingVertices.each do |vert|	# Loop through all vertices in shading face
        
          shadingVertex = vert.position		# For each corner get point3D coordinates (x,y,z)
        
          corners = cornerCoordinates.add_element 'corners'		# Element corners in cornerCoordinates
          x_corner = corners.add_element 'x'		# Element x in corners
          x_corner.add_text (shadingVertex.x * 0.0254).to_s		# Value of x (in xml)
          
          y_corner = corners.add_element 'y'		# Element y in corners
          y_corner.add_text (shadingVertex.y * 0.0254).to_s		# Value of y (in xml)
          
          z_corner = corners.add_element 'z'		# Element z in corners
          z_corner.add_text (shadingVertex.z * 0.0254).to_s		# Value of z (in xml)
        end		# End for each vertex-loop
    end		# End if-loop (material face is ExternalGeometry

#-----INTERNAL WALLS----
	
	if faceMaterial == "InternalWall" || faceBackMaterial == "InternalWall" || faceMaterial == "ExternalWall" || faceBackMaterial == "ExternalWall"
	
		wall = internalWalls.add_element 'wall'		# Element wall in internalWalls
		
		surfaceEdges = wall.add_element 'surfaceEdges'		# Element surfaceEdges in wall
		
		internalWallEdges = fac.outer_loop.edges			# Get edges of face of internal wall
		
		internalWallEdges.each do |edge|		# Loop through all edges in internalWall face
			
			wallEdgeStart = edge.start.position 		# For each corner get Point3D start coordinte (x, y, z)
			wallEdgeEnd = edge.end.position				# For each corner get Point3D end coordinte (x, y, z)
			
			edge = surfaceEdges.add_element 'edge'		# Element edge in surfaceEdges
			start_vertex = edge.add_element 'start'		# Element start in edge
			
			x_coor = start_vertex.add_element 'x'				# Element x in start
			x_coor.add_text (wallEdgeStart.x * 0.0254).to_s		# Value of start vertex x (in xml)
			
			y_coor = start_vertex.add_element 'y'		# Element x in start
			y_coor.add_text (wallEdgeStart.y * 0.0254).to_s	# Value of start vertex y (in xml)
			
			z_coor = start_vertex.add_element 'z'		# Element x in start
			z_coor.add_text (wallEdgeStart.z * 0.0254).to_s	# Value of start vertex z (in xml)
			
			
			end_vertex = edge.add_element 'end'		# Element start in edge
			
			x_coor = end_vertex.add_element 'x'		# Element x in end
			x_coor.add_text (wallEdgeEnd.x * 0.0254).to_s	# Value of end vertex x (in xml)
			
			y_coor = end_vertex.add_element 'y'		# Element x in end
			y_coor.add_text (wallEdgeEnd.y * 0.0254).to_s	# Value of end vertex y (in xml)
			
			z_coor = end_vertex.add_element 'z'		# Element x in end
			z_coor.add_text (wallEdgeEnd.z * 0.0254).to_s	# Value of end vertex z (in xml)

		end   # End for each edge-loop
		
		
		wallNormal = fac.normal		# Get normal of internalWall-face
		
		if faceBackMaterial == "InternalWall"
			wallNormal = Geom::Vector3d.new(-1 * wallNormal.x, -1 * wallNormal.y, -1 * wallNormal.z)	# Get normal of internalWall-face
		end
        
		normal_wall = wall.add_element 'normal'		# Element normal in wall
		
		x_coor = normal_wall.add_element 'x'		# Element x in normal
		x_coor.add_text (wallNormal.x).to_s			# Value of normal vector x (in xml)
			
		y_coor = normal_wall.add_element 'y'		# Element x in start
		y_coor.add_text (wallNormal.y).to_s	# Value of normal vector y (in xml)
			
		z_coor = normal_wall.add_element 'z'		# Element x in start
		z_coor.add_text (wallNormal.z).to_s	# Value of normal vector z (in xml)

	end		#End if (material face is InternalWall)
	
#----INTERNAL CEILINGS-------
	
		if faceMaterial == "InternalCeiling" || faceBackMaterial == "InternalCeiling" || faceMaterial == "Roof" || faceBackMaterial == "Roof" 

	
		ceiling = internalCeilings.add_element 'ceiling'		# Element ceiling in internalCeilings
		surfaceEdges = ceiling.add_element 'surfaceEdges'		# Element surfaceEdges in ceiling
		
		internalCeilingEdges = fac.outer_loop.edges						# Get edges of face of internal ceiling
		
		internalCeilingEdges.each do |edge|				# Loop through all edges in internalCeiling face
			

			ceilingEdgeStart = edge.start.position 		# For each corner get Point3D start coordinte (x, y, z)
			ceilingEdgeEnd = edge.end.position			# For each corner get Point3D end coordinte (x, y, z)
			
			edge = surfaceEdges.add_element 'edge'		# Element edge in surfaceEdges
			start_vertex = edge.add_element 'start'		# Element start in edge
			
			x_coor = start_vertex.add_element 'x'				# Element x in start
			x_coor.add_text (ceilingEdgeStart.x * 0.0254).to_s		# Value of start vertex x (in xml)
			
			y_coor = start_vertex.add_element 'y'		# Element x in start
			y_coor.add_text (ceilingEdgeStart.y * 0.0254).to_s	# Value of start vertex y (in xml)
			
			z_coor = start_vertex.add_element 'z'		# Element x in start
			z_coor.add_text (ceilingEdgeStart.z * 0.0254).to_s	# Value of start vertex z (in xml)
			
			
			end_vertex = edge.add_element 'end'		# Element start in edge
			
			x_coor = end_vertex.add_element 'x'		# Element x in end
			x_coor.add_text (ceilingEdgeEnd.x * 0.0254).to_s	# Value of end vertex x (in xml)
			
			y_coor = end_vertex.add_element 'y'		# Element x in end
			y_coor.add_text (ceilingEdgeEnd.y * 0.0254).to_s	# Value of end vertex y (in xml)
			
			z_coor = end_vertex.add_element 'z'		# Element x in end
			z_coor.add_text (ceilingEdgeEnd.z * 0.0254).to_s	# Value of end vertex z (in xml)

		end   # End for each edge-loop
		
		
		ceilingNormal = fac.normal		# Get normal of internalCeiling-face
		
		if faceBackMaterial == "InternalCeiling"
			ceilingNormal = Geom::Vector3d.new(-1 * ceilingNormal.x, -1 * ceilingNormal.y, -1 * ceilingNormal.z)		# Get normal of internalCeiling-face
		end
        
        
		normal_ceiling = ceiling.add_element 'normal'		# Element normal in ceiling
		
		x_coor = normal_ceiling.add_element 'x'			# Element x in normal
		x_coor.add_text (ceilingNormal.x).to_s			# Value of normal vector x (in xml)
			
		y_coor = normal_ceiling.add_element 'y'		# Element x in start
		y_coor.add_text (ceilingNormal.y).to_s		# Value of normal vector y (in xml)
			
		z_coor = normal_ceiling.add_element 'z'		# Element x in start
		z_coor.add_text (ceilingNormal.z).to_s	# Value of normal vector z (in xml)

	end		#End if (material face is InternalCeiling)

#-----FLOORS-----
	
	if faceMaterial == "Floor" || faceBackMaterial == "Floor" || faceMaterial == "FloorFacingGround" || faceBackMaterial == "FloorFacingGround" 
	
		floor = internalFloors.add_element 'floor'		# Element floor in internalFloors
		surfaceEdges = floor.add_element 'surfaceEdges'		# Element surfaceEdges in floor
		
		internalFloorEdges = fac.edges					# Get edges of face of internal floor
		
		internalFloorEdges.each do |edge|				# Loop through all edges in internalFloor face
			
			floorEdgeStart = edge.start.position 		# For each corner get Point3D start coordinte (x, y, z)
			floorEdgeEnd = edge.end.position			# For each corner get Point3D end coordinte (x, y, z)
			
			edge = surfaceEdges.add_element 'edge'		# Element edge in surfaceEdges
			start_vertex = edge.add_element 'start'		# Element start in edge
			
			x_coor = start_vertex.add_element 'x'				# Element x in start
			x_coor.add_text (floorEdgeStart.x * 0.0254).to_s	# Value of start vertex x (in xml)
			
			y_coor = start_vertex.add_element 'y'				# Element x in start
			y_coor.add_text (floorEdgeStart.y * 0.0254).to_s	# Value of start vertex y (in xml)
			
			z_coor = start_vertex.add_element 'z'				# Element x in start
			z_coor.add_text (floorEdgeStart.z * 0.0254).to_s	# Value of start vertex z (in xml)
			
			
			end_vertex = edge.add_element 'end'		# Element start in edge
			
			x_coor = end_vertex.add_element 'x'		# Element x in end
			x_coor.add_text (floorEdgeEnd.x * 0.0254).to_s	# Value of end vertex x (in xml)
			
			y_coor = end_vertex.add_element 'y'		# Element x in end
			y_coor.add_text (floorEdgeEnd.y * 0.0254).to_s	# Value of end vertex y (in xml)
			
			z_coor = end_vertex.add_element 'z'		# Element x in end
			z_coor.add_text (floorEdgeEnd.z * 0.0254).to_s	# Value of end vertex z (in xml)

		end   # End for each edge-loop
		
		
		floorNormal = fac.normal		# Get normal of internalFloor-face
		
		if floorNormal.z <0 
			floorNormal = Geom::Vector3d.new(-1 * floorNormal.x, -1 * floorNormal.y, -1 * floorNormal.z)		# Get normal of internalFloor-face
		end
        
		normal_floor = floor.add_element 'normal'		# Element normal in floor
		
		x_coor = normal_floor.add_element 'x'			# Element x in normal
		x_coor.add_text (floorNormal.x).to_s			# Value of normal vector x (in xml)
			
		y_coor = normal_floor.add_element 'y'		# Element x in start
		y_coor.add_text (floorNormal.y).to_s		# Value of normal vector y (in xml)
			
		z_coor = normal_floor.add_element 'z'		# Element x in start
		z_coor.add_text (floorNormal.z).to_s	# Value of normal vector z (in xml)

	end		#End if (material face is InternalFloor)

	if faceMaterial == "DaylightGrid" || faceBackMaterial == "DaylightGrid"
	
		grid = internalGrids.add_element 'grid'		# Element gridin internalGrid
		surfaceEdges = grid.add_element 'surfaceEdges'		# Element surfaceEdges in grid
		
		internalGridEdges = fac.edges					# Get edges of face of internal grid
		
		internalGridEdges.each do |edge|				# Loop through all edges in internalGrid face
			
			gridEdgeStart = edge.start.position 		# For each corner get Point3D start coordinte (x, y, z)
			gridEdgeEnd = edge.end.position			# For each corner get Point3D end coordinte (x, y, z)
			
			edge = surfaceEdges.add_element 'edge'		# Element edge in surfaceEdges
			start_vertex = edge.add_element 'start'		# Element start in edge
			
			x_coor = start_vertex.add_element 'x'				# Element x in start
			x_coor.add_text (gridEdgeStart.x * 0.0254).to_s	# Value of start vertex x (in xml)
			
			y_coor = start_vertex.add_element 'y'				# Element x in start
			y_coor.add_text (gridEdgeStart.y * 0.0254).to_s	# Value of start vertex y (in xml)
			
			z_coor = start_vertex.add_element 'z'				# Element x in start
			z_coor.add_text (gridEdgeStart.z * 0.0254).to_s	# Value of start vertex z (in xml)
			
			
			end_vertex = edge.add_element 'end'		# Element start in edge
			
			x_coor = end_vertex.add_element 'x'		# Element x in end
			x_coor.add_text (gridEdgeEnd.x * 0.0254).to_s	# Value of end vertex x (in xml)
			
			y_coor = end_vertex.add_element 'y'		# Element x in end
			y_coor.add_text (gridEdgeEnd.y * 0.0254).to_s	# Value of end vertex y (in xml)
			
			z_coor = end_vertex.add_element 'z'		# Element x in end
			z_coor.add_text (gridEdgeEnd.z * 0.0254).to_s	# Value of end vertex z (in xml)

		end   # End for each edge-loop
		
		
		gridNormal = fac.normal		# Get normal of internalGrid-face
		
		if gridNormal.z <0 
			gridNormal = Geom::Vector3d.new(-1 * gridNormal.x, -1 * gridNormal.y, -1 * gridNormal.z)		# Get normal of internalGrid-face
		end
        
		normal_grid = grid.add_element 'normal'		# Element normal in grid
		
		x_coor = normal_grid.add_element 'x'			# Element x in normal
		x_coor.add_text (gridNormal.x).to_s			# Value of normal vector x (in xml)
			
		y_coor = normal_grid.add_element 'y'		# Element x in start
		y_coor.add_text (gridNormal.y).to_s		# Value of normal vector y (in xml)
			
		z_coor = normal_grid.add_element 'z'		# Element x in start
		z_coor.add_text (gridNormal.z).to_s	# Value of normal vector z (in xml)

	end		#End if (material face is Grid)
	
end	# End for each face-loop
 
 status = `tasklist | find "ICEbearGUI_2.00.exe"`
 if status.empty?
   #Open ICEbear program
   shell = WIN32OLE.new('shell.Application')
   shell.ShellExecute('C:/ICEbear/ICEbearGUI_2.00.exe', '', '', 'open', 1)
   
   File.write(xmlfile, xmldoc)			# Write xml
   File.write(csvfile, csvdoc)			# Write daylightluxlevel.csv
   
 else
   File.write(xmlfile, xmldoc)			# Write xml
   File.write(csvfile, csvdoc)			# Write daylightluxlevel.csv
 end

}

#Create Toolbar icon in Sketchup:
cmd.small_icon = File.dirname(__FILE__) + "/ICEbear/ICEbear_logo.bmp"
cmd.large_icon = File.dirname(__FILE__) + "/ICEbear/ICEbear_logo.bmp"
cmd.tooltip = "ICEbear"
cmd.status_bar_text = "Do an ICEbear simulation"
cmd.menu_text = "ICEbear"
toolbar = toolbar.add_item cmd
toolbar.show
